# Wockstarz multitool
Wockstarz multitool has over 40 features and is a great Discord multitool! It's completely open source.

# DISCLAIMER!!!
This tool is for educational purposes only, I do not condone any illegal / illicit activites. I am not responsible for anything that happens using this tool.

# Usage: 
Run start.bat

## Functions
```yaml
- Functions:
  - Token Formater
  - Token Checker
  - Token Sorter
  - Remove Doubles
  - Token Guild Checker
  - Token Guild Leaver
  - Token Spammer
  - Proxy Scraper
  - Proxy Checker
  - Obfusicator 
  - Token Mail Verifier
  - Token Pass Changer
  - Token Onliner
  - Token Status Rotater
  - Get Own Token
  - Token Login
  - Nitro Gift Checker
  - Token Huminazor
  - Token Watermarker
  - Remove Discord Injection
  - Token Check Payments
  - Token Leave Group Chats
  - Scrape Avatars
  - Token Check Guild Count
  - Token Message everywhere
  - Gen Test Token
  - Token Info
  - Yotube Converter
  - Reverse Image Lookup
  - Ip Lookup
  + Id To token
  + Ip grabber
  + Discord Message Logger
  + Serial Checker
  + Serial Changer
  + Theme Changer
- Webhook Tool:
  - Spam webhook
  - Delete webhook
  - Send message
  - Check webhook
- Faker Tool:
  - Fake Token Gen
  - Fake Mail Gen
  - Fake identity 
  - Fake nitro gen
  - Fake ddos
  - Fake cc's
  - Fake Wallet Miner
  - Social Botter
  + Added Fake Paypal Otp
  + Added Fake Account gen
  + Added Fake Fn Checker
  + Added Explination
- Token Nuker:
  - Nuke Token
  - Leave Server
  - Delete Friends
  - Delete Server
  - Mass dm
  - Close Dms
  - Block All Friends
  - Fuck account
- Token Editor:
  - Change Bio
  - Change Name
  - Change Pronouns
  - Change Pfp
- Discord Nuker:
  - Nuke
- Pc Cleaner:
  - Clean Fivem
  - Clean Recent
  - Clean Crashdump
  - Clean Broswer History
  - Clean Broswer Donwloads
  - Clean Desktop
  - Clean Downloads
```