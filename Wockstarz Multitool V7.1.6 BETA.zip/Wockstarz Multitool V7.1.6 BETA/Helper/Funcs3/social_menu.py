from Helper import *
from Helper.Common.utils import *

def link_start(link):
    os.system(f"start {link}")
    print("Opend Link!")
    time.sleep(1)
    social_menu()


def social_menu():
    new_title("Nexus Socials")
    print(f"{Fore.RESET}[{Fore.RED}1{Fore.RESET}] Wockstarz Discord")
    print(f"[{Fore.RED}2{Fore.RESET}] Wockstarz Github")
    print(f"[{Fore.RED}3{Fore.RESET}] Wockstarz Github")
    print(f"[{Fore.RED}4{Fore.RESET}] Youtube")
    print(f"[{Fore.RED}0{Fore.RESET}] Leave")
    choice = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Choice: ")
    if choice == "1":
        link_start("court69420ondiscord.com")
    elif choice == "2":
        link_start("githubtermed.com")
    elif choice == "3":
        link_start("githubtermed.com")
    elif choice == "4":
        link_start("youtubetermed.com")
    elif choice == "0":
        quit1()
    else:
        print("invalid choice")
        social_menu()