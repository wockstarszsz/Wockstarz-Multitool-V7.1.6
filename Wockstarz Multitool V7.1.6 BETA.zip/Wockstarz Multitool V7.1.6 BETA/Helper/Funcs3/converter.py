from pytube import YouTube
from pytube.exceptions import VideoUnavailable, RegexMatchError
import os

def download_youtube(url, file_type):
    try:
        yt = YouTube(url)
        
        if file_type == 'mp3':
            audio_stream = yt.streams.filter(only_audio=True).first()
            if audio_stream:
                output_path = "Output/Youtube"
                if not os.path.exists(output_path):
                    os.makedirs(output_path)
                audio_stream.download(output_path=output_path)
                print("Audio downloaded successfully!")
            else:
                print("No audio stream available for this video.")
        
        elif file_type == 'mp4':
            video_stream = yt.streams.get_highest_resolution()
            if video_stream:
                output_path = "Output/Youtube"
                if not os.path.exists(output_path):
                    os.makedirs(output_path)
                video_stream.download(output_path=output_path)
                print("Video downloaded successfully!")
            else:
                print("No video stream available for this video.")
        
        else:
            print("Invalid file type. Please choose 'mp3' or 'mp4'.")
    
    except VideoUnavailable:
        print("The video is unavailable.")
    
    except RegexMatchError:
        print("The URL provided does not match a valid video.")
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")

def youtube_converter():
    print("YouTube Converter")
    url = input("Enter the YouTube URL: ")
    file_type = input("Enter 'mp3' for audio or 'mp4' for video: ")
    download_youtube(url, file_type)
    input("Press Enter To continue...")
