from Helper import *
from Helper.Common.utils import *

def generate_fake_credit_card_info():
    temp()