__title__ = 'Wockstarz Multitool'
__author__ = 'Wockstarz'
__copyright__ = 'Made by Wockstarz'
__version__ = '1.1.0'

from Helper.Plugs.FakerPlugs.Funcs.ddoser import *
from Helper.Plugs.FakerPlugs.Funcs.gmailgen import *
from Helper.Plugs.FakerPlugs.Funcs.nitrogen import *
from Helper.Plugs.FakerPlugs.Funcs.person import *
from Helper.Plugs.FakerPlugs.Funcs.tokengen import *
from Helper.Plugs.FakerPlugs.Funcs.cc import *
from Helper.Plugs.FakerPlugs.Funcs.wallet_finder import *
from Helper.Plugs.FakerPlugs.Funcs.social_botter import *
from Helper.Plugs.FakerPlugs.Funcs.paypal_otp import *
from Helper.Plugs.FakerPlugs.Funcs.account_gen import *
from Helper.Plugs.FakerPlugs.Funcs.fortnite_checker import *