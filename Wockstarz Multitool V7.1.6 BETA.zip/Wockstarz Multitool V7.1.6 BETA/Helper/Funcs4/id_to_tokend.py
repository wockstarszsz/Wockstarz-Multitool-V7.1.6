from Helper import *
from Helper.Common.utils import *


def id__token():
    new_title("Id to token Wockstarz")
    id = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Id: ")
    encoded_bytes = base64.urlsafe_b64encode(id.encode("utf-8"))
    token = encoded_bytes.decode("utf-8").rstrip("=")

    print(f"{lc} {Fore.RED}{id} -> {Fore.LIGHTBLUE_EX}{token}")
    input("Press Enter To continue...")
