from Helper import *
from Helper.Common.utils import *
import requests
from bs4 import BeautifulSoup
import time

idx = 0

def Animation():
    global idx
    animation = "|/-\\"
    print(f"{Fore.RED}[{Fore.RESET}+{Fore.RED}]{Fore.RESET} Scraping {animation[idx % len(animation)]}", end="\r", flush=True)
    idx += 1
    time.sleep(0.1)

def reverse_image_lookup():
    new_title("Reverse Image Lookup Wockstarz")
    global idx
    idx = 0

    image_url = input(f"{ld} Image URL: {Fore.RED}{Fore.RESET}").strip()
    
    for _ in range(40):
        Animation()
    
    print(" " * 60, end="\r")
    
    search_url = "https://www.google.com/searchbyimage/upload"
    
    try:
        img_response = requests.get(image_url)
        img_response.raise_for_status()
        
        files = {'encoded_image': ('image.png', img_response.content, 'image/png')}
        response = requests.post(search_url, files=files)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')

        result_stats = soup.find("div", {"class": "bV6vYe"})
        if result_stats:
            result_count_text = result_stats.text
            print(f"{ld} Results found: {Fore.RED}{result_count_text}{Fore.RESET}", flush=True)
        else:
            print(f"{ld} 0 Results found {Fore.RED}{Fore.RESET}", flush=True)
    
    except requests.RequestException as e:
        print(f"Error performing reverse image lookup: {e}")
