from Helper import *
from Helper.Common.utils import *
import time
import os
import shutil

idx = 0

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def Animation():
    global idx
    animation = "|/-\\"
    print(f"{Fore.RED}[{Fore.RESET}+{Fore.RED}]{Fore.RESET} Clearing Cache {animation[idx % len(animation)]}", end="\r", flush=True)
    idx += 1
    time.sleep(0.1)

def clear_cache():
    new_title("Wockstarz Multitool Clear Cache")
    global count
    count = 0  
    global idx  
    idx = 0  

    for _ in range(25):
        Animation()
    
    print(" " * 50, end="\r")
    
    helper_directory = "Helper"
    print(f"Looking for cache in: {os.path.abspath(helper_directory)}")  # Debugging output

    if os.path.exists(helper_directory):
        cache_found = False
        for root, dirs, files in os.walk(helper_directory):
            print(f"Checking in directory: {root}")  # Debugging output
            if '__pycache__' in dirs:
                cache_found = True
                pycache_path = os.path.join(root, '__pycache__')
                try:
                    shutil.rmtree(pycache_path)
                    print(f"{ld} Cache cleared: {pycache_path} {Fore.RESET}", flush=True)
                except Exception as e:
                    print(f"{ld} Error deleting {pycache_path}: {e} {Fore.RED}{Fore.RESET}", flush=True)

        if not cache_found:
            print(f"{ld} No cache found in {helper_directory}. {Fore.RED}{Fore.RESET}", flush=True)
    else:
        print(f"{ld} No cache found. {Fore.RED}{Fore.RESET}", flush=True)