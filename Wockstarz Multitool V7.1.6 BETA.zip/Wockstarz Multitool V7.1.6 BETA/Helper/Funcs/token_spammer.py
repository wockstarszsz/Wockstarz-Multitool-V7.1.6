import requests
import tls_client
import time
from concurrent.futures import ThreadPoolExecutor
from Helper import *
from Helper.Common.utils import *

lc = f"{Fore.RESET}{Fore.LIGHTBLACK_EX}{Style.BRIGHT}[{Fore.RED}N{Style.BRIGHT}{Fore.LIGHTBLACK_EX}]{Fore.RESET}"

session = tls_client.Session(client_identifier="chrome_122", random_tls_extension_order=True)
session.keep_alive = True

def get_tokens():
    """Retrieve tokens from the input file."""
    try:
        with open("Input/tokens.txt", "r") as file:
            tokens = file.readlines()
        return [token.strip() for token in tokens] 
    except FileNotFoundError:
        print("Token file not found.")
        return []  

def send_message(token, channel_id, payload):
    global session
    header = {
        'authorization': token
    }
    try:
        r = session.post(f"https://discord.com/api/v8/channels/{channel_id}/messages", json=payload, headers=header)
    except requests.exceptions.RequestException as e:
        print(f"Error occurred with token: {token}\n{e}")
        return

    if r.status_code == 200:
        print(f"{lc} {Fore.BLUE}token={Fore.WHITE}{token[:20]}...{Fore.RESET} {Fore.LIGHTBLACK_EX}[{Fore.GREEN}Message sent to channel {channel_id}{Fore.LIGHTBLACK_EX}]")
    else:
        print(f"{lc} {Fore.BLUE}token={Fore.WHITE}{token[:20]}...{Fore.RESET} Failed to send message to channel {channel_id}. -> {Fore.LIGHTBLACK_EX}({r.status_code})")

def token_spammer():
    new_title("Token Spammer Wockstarz")
    channel_ids_input = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Input channel IDs separated by commas (Tokens must be in server): ")
    channel_ids = [channel_id.strip() for channel_id in channel_ids_input.split(",")]
    
    content = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Input message to send: ")
    delay = float(input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Input delay between batches in seconds (e.g., 5): "))
    
    tokens = get_tokens()
    if not tokens:  
        print("No tokens found. Exiting...")
        return
    
    tokens = [token.strip() for token in tokens]
    payload = {
        'content': content
    }

    while True:
        with ThreadPoolExecutor() as executor:
            for channel_id in channel_ids:
                for token in tokens:
                    executor.submit(send_message, token, channel_id, payload)
        print(f"{lc} {Fore.BLUE}Waiting for {delay} seconds before sending the next batch...{Fore.RESET}")
        time.sleep(delay) 
