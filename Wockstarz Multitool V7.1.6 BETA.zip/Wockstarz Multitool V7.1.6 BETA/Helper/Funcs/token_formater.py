from Helper import *
from Helper.Common.utils import *
import colorama
from colorama import Fore

def get_tokens():
    """Retrieve tokens from the input file."""
    try:
        with open("Input/tokens.txt", "r") as file:
            tokens = file.readlines()
        return [token.strip() for token in tokens]  
    except FileNotFoundError:
        print("Token file not found.")
        return []  

def formater():
    new_title("Token Formater Wockstarz")
    count = 0
    tokens = get_tokens()

    if tokens is None:
        print("Error: No tokens returned from get_tokens()")
        return 

    new_title("Wockstarz Token Formater")
    change = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Change current token file? (y/n): ")

    if change == "y":
        with open("Input/tokens.txt", "w") as output_file:
            for token in tokens:
                if ":" in token:
                    parts = token.strip().split(":")[2:]
                    new_token = ":".join(parts) + "\n"
                    output_file.write(new_token)
                    count += 1
                    print(f"{lc} {Fore.LIGHTBLUE_EX}token={Fore.WHITE}{new_token[:20]}...{Fore.RESET} Formatted!")
                else:
                    print(f"{lc} {Fore.RED}Skipping token={Fore.WHITE}{token[:20]}...{Fore.RESET} (No colon found)")
                    output_file.write(token)

    with open("Output/formatted_tokens.txt", "w") as output_file:
        for token in tokens:
            if ":" in token:
                parts = token.strip().split(":")[2:]
                new_token = ":".join(parts) + "\n"
                output_file.write(new_token)
                count += 1
                print(f"{lc} {Fore.LIGHTBLUE_EX}token={Fore.WHITE}{new_token[:20]}...{Fore.RESET} Formatted!")
            else:
                print(f"{lc} {Fore.RED}Skipping token={Fore.WHITE}{token[:20]}...{Fore.RESET} (No colon found)")
                output_file.write(token)

    print(f"{ld} Formatted {Fore.GREEN}{count}{Fore.RESET} Tokens!")
    input("Press Enter To continue...")
