from Helper import *
from Helper.Common.utils import *
import requests
import threading

os.system("cls")
tokens911 = []
valid_tokens_count = 0
invalid_tokens_count = 0
nitro_count = 0
unclaimed_count = 0
mail_verified_count = 0
phone_verified_count = 0
full_verified_count = 0
locked_count = 0 
total_checks = 0

def get_tokens():
    """Retrieve tokens from the input file."""
    try:
        with open("Input/tokens.txt", "r") as file:
            tokens = file.readlines()
        return [token.strip() for token in tokens]
    except FileNotFoundError:
        print("Token file not found.")
        return [] 

def check_token_verification(token):
    global valid_tokens_count, invalid_tokens_count, nitro_count, mail_verified_count, unclaimed_count, full_verified_count
    headers = {
        'Authorization': token
    }

    response = requests.get('https://discord.com/api/v10/users/@me', headers=headers)

    if response.status_code == 200:
        data = response.json()
        email_verification = data.get('verified', False)
        phone_verification = bool(data.get('phone'))

        if email_verification and phone_verification:
            full_verified_count += 1
            return "Full Verified"
        elif email_verification:
            mail_verified_count += 1
            return "Mail Verified"
        elif phone_verification:
            phone_verified_count += 1
            return "Phone Verified"
        else:
            unclaimed_count += 1
            return "Unclaimed"
    elif response.status_code == 401:
        return "Invalid"
    else:
        return "Error"

def check_boosts(token):
    headers = {
        'Authorization': f'{token}'
    }

    response = requests.get('https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots', headers=headers)
    if response.status_code == 200:
        data = response.json()
        if data:  
            cooldown_count = sum(1 for entry in data if entry.get('cooldown_ends_at') is not None)
            boosts = 2 - int(cooldown_count)
            return boosts
        else:
            return 0
    else:
        return 0

def check_token(token):
    global valid_tokens_count, invalid_tokens_count, nitro_count, mail_verified_count, unclaimed_count, full_verified_count, locked_count, total_checks
    total_checks += 1
    headers = {
        'Authorization': token
    }

    response = requests.get('https://discord.com/api/v9/users/@me', headers=headers)
    if response.status_code == 200:
        try:
            r = requests.get("https://discordapp.com/api/v6/users/@me/settings", headers=headers)
            if r.status_code == 200:
                valid_tokens_count += 1
                user_data = response.json()
                premium_type = user_data.get('premium_type', 0)  
                verification = check_token_verification(token)
                boosts = check_boosts(token)
                nitro = "NO_NITRO" if premium_type == 0 else "NITRO"
                if premium_type != 0:
                    nitro_count += 1

                print(f'{Fore.BLUE}token={Fore.WHITE}{token[:20]}...{Fore.RESET} Flags: {Fore.LIGHTBLACK_EX}[{Fore.GREEN}VALID{Fore.LIGHTBLACK_EX}] {Fore.LIGHTBLACK_EX}[{Fore.BLUE}{boosts}_BOOSTS{Fore.LIGHTBLACK_EX}] {Fore.LIGHTBLACK_EX}[{Fore.BLUE}{nitro}{Fore.LIGHTBLACK_EX}] {Fore.LIGHTBLACK_EX}[{Fore.BLUE}{verification}{Fore.LIGHTBLACK_EX}] {Fore.LIGHTBLACK_EX}[{Fore.GREEN}UNLOCKED{Fore.LIGHTBLACK_EX}]')
                tokens911.append(token)
                return True
        except Exception as e:
            print(f"Error processing JSON: {e}")
            return False
    else:
        invalid_tokens_count += 1
        print(f'{Fore.BLUE}token={Fore.WHITE}{token[:20]}...{Fore.RESET} Flags: {Fore.LIGHTBLACK_EX}[{Fore.RED}INVALID{Fore.LIGHTBLACK_EX}]')

def Token_checker():
    new_title("Token Checker Wockstarz")
    tokens = get_tokens()

    if tokens is None:
        print("Error: No tokens returned from get_tokens()")
        return 

    tokens = [token.strip() for token in tokens]
    num_threads = 8
    total_tokens = len(tokens)
    tokens_per_thread = total_tokens // num_threads

    def check_tokens_worker(start, end):
        for i in range(start, end):
            token = tokens[i]
            check_token(token)

    threads = []
    for i in range(num_threads):
        start = i * tokens_per_thread
        end = (i + 1) * tokens_per_thread if i < num_threads - 1 else total_tokens
        thread = threading.Thread(target=check_tokens_worker, args=(start, end))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    with open("Output/Valid_Tokens.txt", "w", encoding="utf-8") as file:
        for token in tokens911:
            file.write(f"{token}\n")
    
    print(f"{Fore.GREEN}Valid Tokens: {valid_tokens_count}")
    print(f"{Fore.GREEN}Invalid Tokens: {invalid_tokens_count}")
    print(f"{Fore.GREEN}Locked: {locked_count}")
    print(f"{Fore.GREEN}Nitro: {nitro_count}")
    print(f"{Fore.GREEN}Unclaimed: {unclaimed_count}")
    print(f"{Fore.GREEN}Mail Verified: {mail_verified_count}")
    print(f"{Fore.GREEN}Phone Verified: {phone_verified_count}")
    print(f"{Fore.GREEN}Full Verified: {full_verified_count}")
    print(f"{Fore.GREEN}Total Checks: {total_checks}")
    input("Press Enter To continue...")
