from Helper import *
from Helper.Common.utils import *
import threading
import requests
import time

status_file = ""

def new_title(title):
    print(f"--- {title} ---")

def read_status_texts(filename):
    with open(filename, 'r') as file:
        status_texts = [line.strip() for line in file.readlines()]
    return status_texts

def change_status(token, text):
    headers = get_headers(token)
    setting = {
        'custom_status': {
            'text': text,
        },
    }
    r = requests.patch("https://discord.com/api/v6/users/@me/settings", headers=headers, json=setting)
    if r.status_code == 200:
        print(f"{lc} {Fore.BLUE}token={Fore.WHITE}{token[:20]}...{Fore.RESET} {Fore.RESET}{Fore.LIGHTBLACK_EX}{Style.BRIGHT}[{Fore.GREEN}SUCCESS{Style.BRIGHT}{Fore.LIGHTBLACK_EX}]{Fore.RESET}")
    else:
        print(f"{lc} {Fore.BLUE}token={Fore.WHITE}{token[:20]}...{Fore.RESET} {Fore.RESET}{Fore.LIGHTBLACK_EX}{Style.BRIGHT}[{Fore.RED}ERROR{Style.BRIGHT}{Fore.LIGHTBLACK_EX}]{Fore.RESET} {Fore.RESET}{Fore.LIGHTBLACK_EX}{Style.BRIGHT}({Fore.LIGHTBLACK_EX}{r.status_code}{Style.BRIGHT}{Fore.LIGHTBLACK_EX}){Fore.RESET}")

def status_changer():
    new_title("Token Status Rotator Wockstarz")
    status_file_ask = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Status File (Drag & Drop) (H for help): ")
    if status_file_ask.upper() == "H":
        print(f"{lc} Create a Txt file with a name.")
        print(f"{lc} Every Line Is a new status")
        print(f"{lc} Save it. Then Drag and drop it and press enter.")
        input("Press Enter To continue...")
        clear()
        print(banner)
        status_changer()
    
    global status_file
    status_file = status_file_ask
    tokens_ask = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Use Input/tokens.txt (1) File or single token (2)? (1/2): ")
    if tokens_ask == "1":
        tokens = get_tokens()
        if tokens is None:
            print("Error: No tokens found in the file.")
            return
        tokens = [token.strip() for token in tokens if token.strip()]
    else:
        tokens = [input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Input token: ").strip()]
    
    if not tokens:
        print("Error: No valid tokens provided.")
        return
    
    status_texts = read_status_texts(status_file)
    timefrequency = input(f"{Fore.RESET}[{Fore.RED}>{Fore.RESET}] Time (in seconds): ")
    try:
        timefrequency = int(timefrequency)
    except ValueError:
        print("Error: Invalid time frequency. Please enter a number.")
        return

    while True:
        for text in status_texts:
            threads = []
            for token in tokens:
                thread = threading.Thread(target=change_status, args=(token, text))
                threads.append(thread)
                thread.start()

            for thread in threads:
                thread.join()
            time.sleep(timefrequency)
